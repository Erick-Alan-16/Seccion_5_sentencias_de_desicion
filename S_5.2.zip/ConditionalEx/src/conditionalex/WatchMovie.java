/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conditionalex;

import java.util.Scanner;

/**
 *
 * @author anshenoy
 */
public class WatchMovie {

    public static void main(String args[]) {
        int price, rate;
       Scanner sc = new Scanner(System.in);
       System.out.print("ingresa el precio de la entrada al cine: ");
       price = sc.nextInt();
       System.out.println("ingresa la clasi. de la pelicula: ");
       rate=sc.nextInt();
       if(price>=12 && rate==5)
       {
           System.out.println("estoy interesado en la pelicula");
       }
       else
       {
           System.out.println("no estoy interesado en la pelicula");
       }
        
        

    }
}
