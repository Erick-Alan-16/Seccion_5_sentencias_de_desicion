/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example;

/**
 *
 * @author anshenoy
 */

import java.util.Scanner;
public class StringEquality {
   public static void main (String args[]){
       Scanner src = new Scanner(System.in);
       System.out.println("ingresa tu nombre ");
       String nombre = src.next();
       boolean t1 = nombre.equals("Moe");
       if(t1==true)
       {
           System.out.println("tu eres el rey del rock and roll");
       }
       else
       {
           System.out.println("tu no eres el rey :c");
       }
   }
    
}

